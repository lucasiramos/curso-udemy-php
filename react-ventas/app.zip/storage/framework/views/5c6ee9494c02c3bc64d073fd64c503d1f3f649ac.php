<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
 <title><?php echo e($title); ?></title>
</head>
<body>
  <h1><?php echo e($heading); ?></h1>
  <div>
     <p><?php echo e($content); ?></p>
  </div>
  <p>Estatico</p>
</body>
</body><?php /**PATH C:\wamp64\www\curso-udemy-php\react-ventas\resources\views/pdf_view.blade.php ENDPATH**/ ?>