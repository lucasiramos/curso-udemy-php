<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Chat Room <span id="total_client" class="float-right"></span></div>
                    <div class="card-body">
                        <div id="chat_output" class="pre-scrollable" style="height: 600px">
                            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($message->user_id == auth()->id()): ?>
                                    <span class="text-success"><b><?php echo e($message->user_id); ?>. <?php echo e($message->name); ?>

                                            :</b> <?php echo e($message->message); ?> <span
                                                class="text-warning float-right"><?php echo e(date('Y-m-d h:i a', strtotime($message->created_at))); ?></span></span>
                                    <br><br>
                                <?php else: ?>
                                    <span class="text-info"><b><?php echo e($message->user_id); ?>. <?php echo e($message->name); ?>

                                            :</b> <?php echo e($message->message); ?> <span
                                                class="text-warning float-right"><?php echo e(date('Y-m-d h:i a', strtotime($message->created_at))); ?></span></span>
                                    <br><br>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <input id="chat_input" class="form-control" placeholder="Write Message and Press Enter"/>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('dist/jquery.js')); ?>"></script>
    <script type="text/javascript">

        $('document').ready(function () {
            $("#chat_output").animate({scrollTop: $('#chat_output').prop("scrollHeight")}, 1000); // Scroll the chat output div
        });

        // Websocket
        let ws = new WebSocket("<?php echo e(env('RATCHET_HOST')); ?>:<?php echo e(env('RATCHET_PORT')); ?>");
        ws.onopen = function (e) {
            // Connect to websocket
            console.log('Connected to websocket');
            ws.send(
                JSON.stringify({
                    'type': 'socket',
                    'user_id': '<?php echo e(auth()->id()); ?>'
                })
            );

            // Bind onkeyup event after connection
            $('#chat_input').on('keyup', function (e) {
                if (e.keyCode === 13 && !e.shiftKey) {
                    let chat_msg = $(this).val();
                    ws.send(
                        JSON.stringify({
                            'type': 'chat',
                            'user_id': '<?php echo e(auth()->id()); ?>',
                            'user_name': '<?php echo e(auth()->user()->name); ?>',
                            'chat_msg': chat_msg
                        })
                    );
                    $(this).val('');
                    console.log('<?php echo e(auth()->id()); ?> sent ' + chat_msg);
                }
            });
        };
        ws.onerror = function (e) {
            // Error handling
            console.log(e);
            alert('Check if WebSocket server is running!');
        };
        ws.onclose = function(e) {
            console.log(e);
            alert('Check if WebSocket server is running!');
        };
        ws.onmessage = function (e) {
          console.trace(e);
            let json = JSON.parse(e.data);
            switch (json.type) {
                case 'chat':
                    $('#chat_output').append(json.msg); // Append the new message received
                    $("#chat_output").animate({scrollTop: $('#chat_output').prop("scrollHeight")}, 1000); // Scroll the chat output div
                    console.log("Received " + json.msg);
                    break;

                case 'socket':
                    $('#total_client').html(json.msg);
                    console.log("Received " + json.msg);
                    break;
            }
        };
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>