<?php $__env->startSection('cuerpo'); ?>
	<div class="col-md-12">
		<h1>Página principal</h1>
		<hr class="botm-line">
	</div>
	<div class="col-md-6">
		<h3>¡Bienvenido!</h3>
		<p>Por favor inicie sesión en el siguiente recuadro para comenzar</p>

		<form method="POST" action="<?php echo e(route('login')); ?>">
			<?php echo csrf_field(); ?>

			<label for="email">Email</label>
			<input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
			<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<span class="invalid-feedback" role="alert">
					<strong><?php echo e($message); ?></strong>
				</span>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

			<br>

			<label for="password">Contraseña</label>
			<input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
			<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<span class="invalid-feedback" role="alert">
					<strong><?php echo e($message); ?></strong>
				</span>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

			<br>

			<div class="form-check">
				<input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

				<label class="form-check-label" for="remember">
					Recordar mis datos
				</label>
			</div>

			<br>

			<button type="submit" class="btn btn-primary">
				Iniciar sesión
			</button>

			<?php if(Route::has('password.request')): ?>
				<a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
					<?php echo e(__('Forgot Your Password?')); ?>

				</a>
			<?php endif; ?>
		</form>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\curso-udemy-php\estilos-auth-maps\resources\views/index.blade.php ENDPATH**/ ?>